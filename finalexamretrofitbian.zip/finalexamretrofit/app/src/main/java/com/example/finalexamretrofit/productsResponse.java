package com.example.finalexamretrofit;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class productsResponse {
    @SerializedName("products")

    ArrayList<products> productsArrayList;

    public ArrayList<products> getProductsArrayList() {
        return productsArrayList;
    }

    public void setProductsArrayList(ArrayList<products> productsArrayList) {
        this.productsArrayList = productsArrayList;
    }

    public productsResponse(ArrayList<products> productsArrayList) {
        this.productsArrayList = productsArrayList;
    }
}
class products{
    @SerializedName("title")

    String title;
    @SerializedName("price")

    int price;
    @SerializedName("thumbnail")

    String thumbnail;
    @SerializedName("smartphones")
    String smartphones;
    @SerializedName("Host")
    String Host;

    @SerializedName("User-Agent")
    String User_Agent;
    @SerializedName("Accept")
    String Accept;
    @SerializedName("Accept-Encoding")
    String Accept_Encoding;
    @SerializedName("Connection")
    String Connection;

    @Override
    public String toString() {
        return "products{" +
                "title='" + title + '\'' +
                ", price=" + price +
                ", thumbnail='" + thumbnail + '\'' +
                ", smartphones='" + smartphones + '\'' +
                ", Host='" + Host + '\'' +
                ", User_Agent='" + User_Agent + '\'' +
                ", Accept='" + Accept + '\'' +
                ", Accept_Encoding='" + Accept_Encoding + '\'' +
                ", Connection='" + Connection + '\'' +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getSmartphones() {
        return smartphones;
    }

    public void setSmartphones(String smartphones) {
        this.smartphones = smartphones;
    }

    public String getHost() {
        return Host;
    }

    public void setHost(String host) {
        Host = host;
    }

    public String getUser_Agent() {
        return User_Agent;
    }

    public void setUser_Agent(String user_Agent) {
        User_Agent = user_Agent;
    }

    public String getAccept() {
        return Accept;
    }

    public void setAccept(String accept) {
        Accept = accept;
    }

    public String getAccept_Encoding() {
        return Accept_Encoding;
    }

    public void setAccept_Encoding(String accept_Encoding) {
        Accept_Encoding = accept_Encoding;
    }

    public String getConnection() {
        return Connection;
    }

    public void setConnection(String connection) {
        Connection = connection;
    }

    public products(String title, int price, String thumbnail, String smartphones, String host, String user_Agent, String accept, String accept_Encoding, String connection) {
        this.title = title;
        this.price = price;
        this.thumbnail = thumbnail;
        this.smartphones = smartphones;
        Host = host;
        User_Agent = user_Agent;
        Accept = accept;
        Accept_Encoding = accept_Encoding;
        Connection = connection;
    }
}
