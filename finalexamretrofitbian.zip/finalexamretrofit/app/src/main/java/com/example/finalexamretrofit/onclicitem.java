package com.example.finalexamretrofit;

public interface onclicitem {
    void onclicitem();
}
