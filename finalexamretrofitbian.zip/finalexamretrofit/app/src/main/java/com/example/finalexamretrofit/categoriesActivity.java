package com.example.finalexamretrofit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import com.example.finalexamretrofit.databinding.ActivityCategoriesBinding;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class categoriesActivity extends AppCompatActivity {
ActivityCategoriesBinding binding;
    ApiServices retrofitInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityCategoriesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
getOrder();
    }
    private void getOrder() {
        retrofitInstance=  ApiServices.RetrofitClass.getRetrofitInstance();

        retrofitInstance.categories().enqueue(new Callback<List<String>>() {
            @Override
            public void onResponse(Call<List<String>> call, Response<List<String>> response) {
                List<String> stringList=response.body();
categoresAdapter adapter=new categoresAdapter(stringList, categoriesActivity.this, new onclicitem() {
    @Override
    public void onclicitem() {
        Intent intent=new Intent(getApplicationContext(),productsCategores.class);
    }
});
binding.rv.setAdapter(adapter);
binding.rv.setLayoutManager(new LinearLayoutManager(getApplicationContext(),RecyclerView.VERTICAL,false));

            }


            @Override
            public void onFailure(Call<List<String>> call, Throwable t) {

            }
        });
    }
}